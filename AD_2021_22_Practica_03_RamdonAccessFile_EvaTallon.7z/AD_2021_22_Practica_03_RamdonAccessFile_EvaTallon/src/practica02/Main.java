
package practica02;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class Main extends javax.swing.JFrame {
    
      
       File fichero= new File("Alumnos.txt"); 
       
       RandomAccessFile raf;
      DefaultTableModel modelo = new DefaultTableModel();
       ArrayList<Alumnos> alumno = new ArrayList<>();
       long puntero ;
       int posicion;
       String datos[] = new String[3];
        char nombre[]= new char[10];
    
    public Main() {
        initComponents();
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int height = 800;
        int width = pantalla.width;
        setSize(width/2, height);	

        setLocationRelativeTo(null);		
        setVisible(true);

        modelo.addColumn("Nº MATRÍCULA");
        modelo.addColumn("NOTA");
        modelo.addColumn("NOMBRE");
      
       this.jTable1.setModel(modelo);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelAlta = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtId1 = new javax.swing.JFormattedTextField();
        txtNota1 = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        btnAlta = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtNom1 = new javax.swing.JFormattedTextField();
        PanelBaja = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtId2 = new javax.swing.JFormattedTextField();
        btnBaja = new javax.swing.JButton();
        PanelModif = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtId3 = new javax.swing.JFormattedTextField();
        txtNota3 = new javax.swing.JFormattedTextField();
        btnModif = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        txtNom3 = new javax.swing.JFormattedTextField();
        PanelBuscar = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtId4 = new javax.swing.JFormattedTextField();
        btnBuscar = new javax.swing.JButton();
        txtNota4 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtNom4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnRefrescar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        PanelAlta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelAlta.setPreferredSize(new java.awt.Dimension(254, 100));
        PanelAlta.setLayout(null);

        jLabel1.setText("Nº MATRICULA");
        jLabel1.setOpaque(true);
        PanelAlta.add(jLabel1);
        jLabel1.setBounds(10, 40, 90, 16);

        jLabel2.setText("NOTA");
        jLabel2.setOpaque(true);
        PanelAlta.add(jLabel2);
        jLabel2.setBounds(10, 70, 90, 16);

        txtId1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        txtId1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtId1ActionPerformed(evt);
            }
        });
        txtId1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtId1KeyTyped(evt);
            }
        });
        PanelAlta.add(txtId1);
        txtId1.setBounds(120, 40, 90, 22);

        txtNota1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        txtNota1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNota1ActionPerformed(evt);
            }
        });
        txtNota1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNota1KeyTyped(evt);
            }
        });
        PanelAlta.add(txtNota1);
        txtNota1.setBounds(120, 70, 90, 22);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("ALTA");
        PanelAlta.add(jLabel3);
        jLabel3.setBounds(10, 10, 37, 17);

        btnAlta.setText("ALTA");
        btnAlta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAltaActionPerformed(evt);
            }
        });
        PanelAlta.add(btnAlta);
        btnAlta.setBounds(130, 130, 80, 20);

        jLabel12.setText("NOMBRE");
        PanelAlta.add(jLabel12);
        jLabel12.setBounds(10, 100, 60, 16);

        txtNom1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNom1KeyTyped(evt);
            }
        });
        PanelAlta.add(txtNom1);
        txtNom1.setBounds(120, 100, 90, 22);

        getContentPane().add(PanelAlta);
        PanelAlta.setBounds(30, 30, 230, 160);

        PanelBaja.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelBaja.setPreferredSize(new java.awt.Dimension(254, 100));
        PanelBaja.setLayout(null);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("BAJA");
        PanelBaja.add(jLabel4);
        jLabel4.setBounds(10, 10, 37, 17);

        jLabel5.setText("Nº MATRICULA");
        PanelBaja.add(jLabel5);
        jLabel5.setBounds(10, 50, 100, 16);

        txtId2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtId2ActionPerformed(evt);
            }
        });
        txtId2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtId2KeyTyped(evt);
            }
        });
        PanelBaja.add(txtId2);
        txtId2.setBounds(110, 50, 110, 22);

        btnBaja.setText("BAJA");
        btnBaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBajaActionPerformed(evt);
            }
        });
        PanelBaja.add(btnBaja);
        btnBaja.setBounds(140, 90, 70, 25);

        getContentPane().add(PanelBaja);
        PanelBaja.setBounds(30, 210, 230, 120);

        PanelModif.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelModif.setPreferredSize(new java.awt.Dimension(254, 100));
        PanelModif.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("MODIFICAR");
        PanelModif.add(jLabel6);
        jLabel6.setBounds(10, 10, 100, 17);

        jLabel7.setText("Nº MATRICULA");
        PanelModif.add(jLabel7);
        jLabel7.setBounds(10, 40, 100, 16);

        jLabel8.setText("NOTA");
        PanelModif.add(jLabel8);
        jLabel8.setBounds(10, 70, 40, 16);
        PanelModif.add(txtId3);
        txtId3.setBounds(120, 30, 100, 22);

        txtNota3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNota3ActionPerformed(evt);
            }
        });
        PanelModif.add(txtNota3);
        txtNota3.setBounds(120, 70, 100, 22);

        btnModif.setText("MODIFICAR");
        btnModif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModifActionPerformed(evt);
            }
        });
        PanelModif.add(btnModif);
        btnModif.setBounds(110, 140, 110, 25);

        jLabel14.setText("NOMBRE");
        PanelModif.add(jLabel14);
        jLabel14.setBounds(10, 110, 49, 16);

        txtNom3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNom3KeyTyped(evt);
            }
        });
        PanelModif.add(txtNom3);
        txtNom3.setBounds(110, 110, 110, 22);

        getContentPane().add(PanelModif);
        PanelModif.setBounds(30, 360, 230, 180);

        PanelBuscar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelBuscar.setPreferredSize(new java.awt.Dimension(254, 100));
        PanelBuscar.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("BUSCAR");
        PanelBuscar.add(jLabel9);
        jLabel9.setBounds(10, 10, 80, 17);

        jLabel10.setText("Nº MATRICULA");
        PanelBuscar.add(jLabel10);
        jLabel10.setBounds(10, 40, 90, 16);

        jLabel11.setText("NOTA");
        PanelBuscar.add(jLabel11);
        jLabel11.setBounds(10, 70, 33, 16);

        txtId4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtId4ActionPerformed(evt);
            }
        });
        PanelBuscar.add(txtId4);
        txtId4.setBounds(120, 40, 90, 22);

        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        PanelBuscar.add(btnBuscar);
        btnBuscar.setBounds(130, 130, 79, 25);

        txtNota4.setBackground(new java.awt.Color(255, 255, 255));
        txtNota4.setOpaque(true);
        PanelBuscar.add(txtNota4);
        txtNota4.setBounds(120, 70, 90, 20);

        jLabel13.setText("NOMBRE");
        PanelBuscar.add(jLabel13);
        jLabel13.setBounds(10, 100, 60, 16);

        txtNom4.setBackground(new java.awt.Color(255, 255, 255));
        txtNom4.setOpaque(true);
        PanelBuscar.add(txtNom4);
        txtNom4.setBounds(120, 100, 90, 20);

        getContentPane().add(PanelBuscar);
        PanelBuscar.setBounds(30, 560, 230, 170);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(420, 20, 280, 530);

        btnRefrescar.setText("REFRESCAR");
        btnRefrescar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefrescarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRefrescar);
        btnRefrescar.setBounds(570, 600, 110, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtId1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtId1ActionPerformed
        
 
         
    }//GEN-LAST:event_txtId1ActionPerformed

    private void txtId2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtId2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtId2ActionPerformed

    private void txtId4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtId4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtId4ActionPerformed

    private void btnAltaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAltaActionPerformed
        int id = Integer.parseInt(txtId1.getText());
        Double nota = Double.parseDouble(txtNota1.getText().replace(",", "."));
        String nombre = txtNom1.getText();
       
        if(txtId1.getText().isEmpty() || txtNota1.getText().isEmpty()||txtNom1.getText().isEmpty() ){
        JOptionPane.showMessageDialog(this,"Rellena todos los campos");
        }
        else{
            altaAlumno(id,nota,nombre);
        }
      
                       
         
          
    }//GEN-LAST:event_btnAltaActionPerformed

    private void txtNota1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNota1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNota1ActionPerformed

    private void btnBajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBajaActionPerformed
        int id = Integer.parseInt(txtId2.getText());
        if(txtId2.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Campo vacio");
        }
        else{
            bajaAlumno(id);           
        }
 
           
  
    }//GEN-LAST:event_btnBajaActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
       if(txtId4.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Campo vacio");
        
       }
       else{
            int id = Integer.parseInt(txtId4.getText());
         Double nota;
         if(buscarAlumno(id)==true){
             try {
                 JOptionPane.showMessageDialog(this,"Nº encontrado");
                 puntero=((Integer.parseInt(txtId4.getText())-1)*32);
                 raf.seek(puntero);
                 raf.readInt();
                 nota = raf.readDouble();
                  for(int i =0;i<nombre.length;i++){
                    char aux = raf.readChar();
                    nombre[i]=aux;     
                 }   
                  String nom = new String(nombre);
                 txtNota4.setText(String.valueOf(nota));
                 txtNom4.setText(nom);
             } catch (IOException ex) {
                 System.out.println(ex.getMessage());
             }
         }
         else{
             JOptionPane.showMessageDialog(this,"Nº no encontrado");
             txtId4.setText("");
             txtNota4.setText("");
             txtNom4.setText("");
             
         }
         
       }
       
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtId1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtId1KeyTyped
         if (Character.isLetter(evt.getKeyChar())&&!(evt.getKeyChar() == KeyEvent.VK_SPACE)
               && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
                    evt.consume();
                       JOptionPane.showMessageDialog(this,"Escribe solo numeros","mensaje",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_txtId1KeyTyped

    private void txtNota1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNota1KeyTyped
         if (Character.isLetter(evt.getKeyChar())&&!(evt.getKeyChar() == KeyEvent.VK_SPACE)
               && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
                    evt.consume();
                       JOptionPane.showMessageDialog(this,"Escribe solo numeros","mensaje",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_txtNota1KeyTyped

    private void txtId2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtId2KeyTyped
         if (Character.isLetter(evt.getKeyChar())&&!(evt.getKeyChar() == KeyEvent.VK_SPACE)
               && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
                    evt.consume();
                       JOptionPane.showMessageDialog(this,"Escribe solo numeros","mensaje",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_txtId2KeyTyped

    private void btnModifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModifActionPerformed
        int id = Integer.parseInt(txtId3.getText());
        
         if(txtId3.getText().isEmpty() || txtNota3.getText().isEmpty()||txtNom3.getText().isEmpty() ){
        JOptionPane.showMessageDialog(this,"Rellena todos los campos");
        }
         else{
            modificarAlumno(id);
         }
        
        
    }//GEN-LAST:event_btnModifActionPerformed

    private void txtNota3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNota3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNota3ActionPerformed

    private void txtNom1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNom1KeyTyped
        if (!Character.isLetter(evt.getKeyChar())&&!(evt.getKeyChar() == KeyEvent.VK_SPACE)
               && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
                    evt.consume();
                       JOptionPane.showMessageDialog(this,"Escribe solo letras","mensaje",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_txtNom1KeyTyped

    private void txtNom3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNom3KeyTyped
        if (!Character.isLetter(evt.getKeyChar())&&!(evt.getKeyChar() == KeyEvent.VK_SPACE)
               && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) {
                    evt.consume();
                       JOptionPane.showMessageDialog(this,"Escribe solo letras","mensaje",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_txtNom3KeyTyped

    private void btnRefrescarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefrescarActionPerformed
       
       modelo.setRowCount(0);
        try {
               
            raf.seek(0);
            while(raf.getFilePointer()<raf.length()){
                int id = raf.readInt();
                if(id!=0){
                    datos[0]=String.valueOf(id);
                    Double nota = raf.readDouble();
                    datos[1] =String.valueOf(nota);
                    for(int i =0;i<nombre.length;i++){
                        char aux = raf.readChar();
                        nombre[i]=aux; 
                     }
                    String nom = new String (nombre);  
                    datos[2]=nom;
                    modelo.addRow(datos);  
                }
                else{
                    raf.readDouble();
                    for(int i =0;i<nombre.length;i++){
                        char aux = raf.readChar();
                        nombre[i]=aux; 
                     }
                }
   
                     }} catch (IOException ex) {
               System.out.println(ex.getMessage());
           }
        
    }//GEN-LAST:event_btnRefrescarActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
  
                new Main();
            }
        });
    }
    
    public boolean comprobarId(int id){
        boolean unico=true;
        for(Alumnos al : alumno){
            if(id==al.getId()){
                unico=false;             
            }
        }
        return unico;
    }

  public void altaAlumno(int id,Double nota,String nombre){

    if(comprobarId(id)==false){
        JOptionPane.showMessageDialog(this,"Nº de matricula repetido","MENSAJE",JOptionPane.INFORMATION_MESSAGE);
        txtId1.setText("");
        txtNota1.setText("");
        txtNom1.setText("");
        }
        else{
            if(id==0){
               JOptionPane.showMessageDialog(this,"Nº de matriculepea no puede ser 0","MENSAJE",JOptionPane.INFORMATION_MESSAGE);
               txtId1.setText("");
               txtNota1.setText("");
               txtNom1.setText("");
                txtNom1.setText("");
            }
            else{
                if(nota<0 || nota >10){
                    JOptionPane.showMessageDialog(this, "Nota incorrecta");
                }
                else{
                try {
                  try {
                    raf = new RandomAccessFile(fichero,"rw");
                     } catch (FileNotFoundException ex) {
                       System.out.println(ex.getMessage());
                     } 
                  
                    puntero=((Integer.parseInt(txtId1.getText())-1)*32);
                    raf.seek(puntero);
                    
                    } catch (IOException ex) {
                        System.out.println("Error: "+ex.getMessage());
                    }
                   try {
                    raf.writeInt(id);
                    raf.writeDouble(nota);
                    StringBuffer sb = new StringBuffer(txtNom1.getText());
                    sb.setLength(10);
                    raf.writeChars(sb.toString());
                    Alumnos al1 = new Alumnos(id,nota,nombre);
                    alumno.add(al1);   
                     
                    
                     datos[0]=String.valueOf(id) ;
                     datos[1]=String.valueOf(nota);
                     datos[2]=txtNom1.getText();
                     modelo.addRow(datos);
                    JOptionPane.showMessageDialog(this,"Alta correcta");
                    txtId1.setText("");
                    txtNota1.setText("");
                     txtNom1.setText("");
                    
                 } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                  }
                }
        
            }
        }
  }
                  
public void bajaAlumno(int id) {
    
    if(id==0){
        JOptionPane.showMessageDialog(this, "No puedes borrar registro con Nº 0");
    }  
    else{
        if(buscarAlumno(id)==false){
            JOptionPane.showMessageDialog(this,"Nº no encontrado");
        }
    else{
        int dialogo = JOptionPane.showConfirmDialog(this,"¿Seguro que desea borrarlo?");                
            if(dialogo==JOptionPane.YES_OPTION){
                try {
                puntero=((Integer.parseInt(txtId2.getText())-1)*32);
                raf.seek(puntero);
                raf.writeInt(0);
                txtId2.setText("");
   
                JOptionPane.showMessageDialog(this, "Borrado correctamente");
                         
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
         }
      }            
 }
     
public boolean buscarAlumno(int id){
   boolean encontrado=false;
  
   try {
         try {
            raf.seek(0);
       } catch (IOException ex) {
            System.out.println(ex.getMessage());
       }            
        while(raf.getFilePointer()<raf.length()){
            if(id==raf.readInt()){
                 encontrado=true;
            }
            raf.readDouble();
            for(int i =0;i<nombre.length;i++){
                char aux = raf.readChar();
                nombre[i]=aux;     
            }
       }
     
       } catch (IOException ex) {
           System.out.println(ex.getMessage());
      }
         return encontrado;
   }

public void modificarAlumno(int id){
    Double nota = Double.parseDouble(txtNota3.getText().replace(",", "."));
    
    if(txtId3.getText().isEmpty() || txtNota3.getText().isEmpty()){
        JOptionPane.showMessageDialog(this,"Ambos campos desben estar rellenados");
    }
    else{
        if(nota<0||nota>10){
            JOptionPane.showMessageDialog(this,"Nota incorrecta");
        }
        else{
            if(buscarAlumno(id)==true){
                int op=JOptionPane.showConfirmDialog(this,"¿Seguro que quieres modificarlo?");
                if(op ==JOptionPane.YES_OPTION){
                    try {
                        puntero= ((Integer.parseInt(txtId3.getText())-1)*32);
                        raf.seek(puntero);
                        raf.readInt();
                        raf.writeDouble(nota);
                        StringBuffer sb = new StringBuffer(txtNom3.getText());
                        sb.setLength(10);
                        raf.writeChars(sb.toString());
                         txtId3.setText("");
                        txtNota3.setText("");
                        txtNom3.setText("");
                        JOptionPane.showMessageDialog(this,"Modificado correctamente");
                    } catch (IOException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
            
            }
            else if(buscarAlumno(id)==false){
                int op=JOptionPane.showConfirmDialog(this,"Matricula no existe, ¿Desea crearlo?");
                if(op ==JOptionPane.YES_OPTION){
                    try {
                        puntero = ((Integer.parseInt(txtId3.getText())-1)*32);
                        raf.seek(puntero);
                        raf.writeInt(id);
                        raf.writeDouble(nota);
                        StringBuffer sb = new StringBuffer(txtNom3.getText());
                        sb.setLength(10);
                        raf.writeChars(sb.toString());
                        
                        JOptionPane.showMessageDialog(this,"Creado correctamente");
                        txtId3.setText("");
                        txtNota3.setText("");
                        txtNom3.setText("");
                    } catch (IOException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
            }
        
        }
    }
    
}
    
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelAlta;
    private javax.swing.JPanel PanelBaja;
    private javax.swing.JPanel PanelBuscar;
    private javax.swing.JPanel PanelModif;
    private javax.swing.JButton btnAlta;
    private javax.swing.JButton btnBaja;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnModif;
    private javax.swing.JButton btnRefrescar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JFormattedTextField txtId1;
    private javax.swing.JFormattedTextField txtId2;
    private javax.swing.JFormattedTextField txtId3;
    private javax.swing.JFormattedTextField txtId4;
    private javax.swing.JFormattedTextField txtNom1;
    private javax.swing.JFormattedTextField txtNom3;
    private javax.swing.JLabel txtNom4;
    private javax.swing.JFormattedTextField txtNota1;
    private javax.swing.JFormattedTextField txtNota3;
    private javax.swing.JLabel txtNota4;
    // End of variables declaration//GEN-END:variables

   
}
